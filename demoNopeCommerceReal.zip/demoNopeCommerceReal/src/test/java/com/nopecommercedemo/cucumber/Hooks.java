package com.nopecommercedemo.cucumber;

import com.cucumber.listener.Reporter;
import com.nopecommercedemo.propertyreader.PropertyReader;
import com.nopecommercedemo.utility.Utility;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import org.openqa.selenium.NoSuchSessionException;

import java.io.IOException;
import java.net.MalformedURLException;

public class Hooks extends Utility {

    @Before
    public void setUp() throws MalformedURLException {
        selectBrowser(PropertyReader.getInstance().getProperty("browser"));
        String activeProfile = System.getProperty("activatedProfile");
        System.out.println("Active Profile: " + activeProfile);
    }
    @After
    public void tearDown(Scenario scenario) throws IOException {
        if (scenario.isFailed()) {
            String screenShotPath = Utility.getScreenshot(driver, scenario.getName().replace(" ", "_"));
            try {
                Reporter.addScreenCaptureFromPath(screenShotPath);
            } catch (IOException e) {
                e.printStackTrace();
            } catch (NoSuchSessionException e) {
                System.out.println("Session not found.");
            } finally {
                Utility.closeWebDriver(driver);
            }
        }
    }


}
